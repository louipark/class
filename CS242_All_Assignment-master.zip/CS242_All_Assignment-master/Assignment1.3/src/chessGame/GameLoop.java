package chessGame;

import gui.Graphic;

/*
 * Start a new game.
 */
public class GameLoop {

	public static void main(String[] args){
		
		
		Graphic myChessGame = new Graphic();
		
	}
}
