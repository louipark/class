<?php
/**
 * Created by JetBrains PhpStorm.
 * User: shengchao
 * Date: 3/13/13
 * Time: 10:43 PM
 * To change this template use File | Settings | File Templates.
 */

$comment = $_POST['comment'];
$name = $_POST['user'];

echo $comment . ' ' . $name;