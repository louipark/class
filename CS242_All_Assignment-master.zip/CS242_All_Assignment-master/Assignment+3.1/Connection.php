<?php
/**
 * Created by JetBrains PhpStorm.
 * User: shengchao
 * Date: 3/12/13
 * Time: 5:31 PM
 * To change this template use File | Settings | File Templates.
 */

$host = 'engr-cpanel-mysql.engr.illinois.edu';
$user = 'huangfu2_shen';
$password = 'cs242';
$dbconn = mysql_connect($host, $user, $password) or die ('Could not connect to database: ' . mysql_error());
mysql_select_db('huangfu2_comment', $dbconn) or die("Cannot select the database");

