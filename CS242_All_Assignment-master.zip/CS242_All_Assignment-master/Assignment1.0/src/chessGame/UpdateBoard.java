package chessGame;

public class UpdateBoard {
	//Print the game board
	public static void printBoard(){
		for( int i = 0; i < 100; i++ ){
			System.out.print(MyGame.board[i] + " ");
			if( MyGame.board[i] == 0 )
				System.out.print(" ");
			if( (i + 1) % 10 == 0 )
				System.out.print('\n');
		}
		System.out.println("------------------------------------");
	}
	
	
}
