package pieces;

public class Queen {

	public static boolean queenMoveValid(int piecePosition, int movePosition) {
		
		if( Bishop.bishopMoveValid(piecePosition, movePosition) || Rook.rookMoveValid(piecePosition, movePosition) )
				return true;
		else return false;
		
		
		
	}
	
}
