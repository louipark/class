
function toggle(el)
{
el.style.display = (el.style.display == "none") ? "block" : "none";
}





