'''
Created on Feb 20, 2013

@author: shengchao
'''

class RouteInfo:
    
    def __init__(self, takeOffPort, landPort, distance):
        self.takeOffPortCode = takeOffPort
        self.landPortCode = landPort
        self.distance = distance
        
        

