'''
Created on Feb 20, 2013

@author: shengchao
'''

cityDicationary = {}
routeList = []
codeToName = {}

#Static data
longestSingleFlight = 0
shortestSingleFlight = 0
averageDistance = 0
biggestCity = 0
smallestCity = 0
averageCitySize = 0
hubCity = {}

northAmerica = []
southAmerica = []
europe = []
asia = []
africa = []
australia = []


