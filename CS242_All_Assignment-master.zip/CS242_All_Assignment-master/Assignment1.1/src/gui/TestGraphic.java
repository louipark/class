package gui;

import chessGame.MyGame;

public class TestGraphic {

	public static void main(String[] args){
		
		MyGame newGame = new MyGame();
		
		MyGame.initBoard();
		
		MyGame.whitePlayerScore = 0;
		MyGame.blackPlayerScore = 0;
		
		Graphic myChessGame = new Graphic();
		
	}
}
